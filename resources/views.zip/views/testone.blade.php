@extends('layouts.app', ['title' => 'প্রশ্ন ব্যাংক ও মডেল টেস্ট সিস্টেম'])

@section('content')

@include('partials.header')

    <div id="app" class="grid lg:grid-cols-[1fr_2fr_2fr] min-h-screen">

        @include('partials.aside')

        @include('partials.block2')

        @include('partials.block3')

        @include('partials.block4')

        @include('partials.preview')
    </div>

@endsection